import {
  GitBranch,
  Layers,
  ScrollText,
  TerminalSquare,
  Rocket,
} from 'lucide-react'

const features = [
  {
    icon: Layers,
    title: 'Multi-agent concurrency control',
    description:
      'Run hundreds of agents in parallel without them stepping on each other. Deterministic scheduling and isolation keep every workload safe and reproducible.',
  },
  {
    icon: GitBranch,
    title: 'Copy-on-write cloning',
    description:
      'O(1) space for N parallel sandboxes from a single base image. Fork an environment instantly and only pay for what actually changes.',
  },
  {
    icon: ScrollText,
    title: 'Agent operation audit',
    description:
      'Every command, file write, and network call is recorded. Replay exactly what an agent did, when, and why — for debugging and compliance.',
  },
  {
    icon: TerminalSquare,
    title: 'Codex-style agent tools',
    description:
      'First-class shell, write, and edit primitives designed for LLM agents, so your models can operate a real machine with predictable, structured tools.',
  },
  {
    icon: Rocket,
    title: 'Fast, universal deploy',
    description:
      'Deploy anywhere — macOS, Linux, Windows, and any Docker image. One runtime that runs the same everywhere your agents need to go.',
    wide: true,
  },
]

export function Features() {
  return (
    <section id="features" className="mx-auto max-w-6xl px-4 py-20 md:px-6 md:py-24">
      <div className="mx-auto mb-14 max-w-2xl text-center">
        <p className="mb-3 text-sm font-medium uppercase tracking-widest text-primary">
          Everything agents need
        </p>
        <h2 className="text-balance text-3xl font-semibold tracking-tight md:text-4xl">
          A complete runtime for autonomous work
        </h2>
        <p className="mt-4 text-pretty text-lg leading-relaxed text-muted-foreground">
          Ephemeral-OS packs the primitives you need to run agents at scale — safely, cheaply, and
          with total visibility.
        </p>
      </div>

      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {features.map((feature) => (
          <article
            key={feature.title}
            className={`group flex flex-col gap-4 rounded-2xl border border-border bg-card p-6 transition-colors hover:border-primary/50 ${
              feature.wide ? 'sm:col-span-2 lg:col-span-1' : ''
            }`}
          >
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary">
              <feature.icon className="size-5" />
            </div>
            <h3 className="text-lg font-semibold tracking-tight text-card-foreground">
              {feature.title}
            </h3>
            <p className="text-pretty leading-relaxed text-muted-foreground">
              {feature.description}
            </p>
          </article>
        ))}
      </div>
    </section>
  )
}
