import Image from 'next/image'
import { ArrowRight, Terminal } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden">
      <div className="mx-auto grid max-w-6xl items-center gap-12 px-4 py-20 md:px-6 md:py-28 lg:grid-cols-2">
        <div className="flex flex-col items-start gap-6">
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-muted-foreground">
            <span className="h-1.5 w-1.5 rounded-full bg-primary" />
            Isolated runtimes for autonomous agents
          </span>

          <h1 className="text-pretty text-4xl font-semibold leading-tight tracking-tight md:text-5xl lg:text-6xl">
            Give every agent its own{' '}
            <span className="text-primary">disposable sandbox</span>
          </h1>

          <p className="max-w-xl text-pretty text-lg leading-relaxed text-muted-foreground">
            Ephemeral-OS spins up secure, throwaway environments where AI agents can run shell
            commands, edit files, and ship code — with concurrency control, instant cloning, and a
            full audit trail baked in.
          </p>

          <div className="flex flex-col gap-3 sm:flex-row">
            <Button size="lg" nativeButton={false} render={<a href="#cta" />}>
              Start building free
              <ArrowRight className="size-4" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              nativeButton={false}
              render={<a href="#features" />}
            >
              Explore features
            </Button>
          </div>

          <div className="mt-2 w-full max-w-md rounded-xl border border-border bg-card p-4 font-mono text-sm shadow-sm">
            <div className="mb-3 flex items-center gap-2 text-muted-foreground">
              <Terminal className="size-4 text-primary" />
              <span className="text-xs">bash</span>
            </div>
            <code className="block leading-relaxed">
              <span className="text-muted-foreground">$</span> eos spawn --agents 128
              <br />
              <span className="text-primary">✓</span> 128 sandboxes ready in 0.4s
              <br />
              <span className="text-muted-foreground">$</span> eos audit --tail
            </code>
          </div>
        </div>

        <div className="relative flex justify-center lg:justify-end">
          <Image
            src="/ephemeral-os-logo.png"
            alt="Ephemeral-OS mascot: a friendly robot inside a shipping box"
            width={520}
            height={520}
            className="h-auto w-full max-w-md drop-shadow-2xl"
            priority
          />
        </div>
      </div>
    </section>
  )
}
