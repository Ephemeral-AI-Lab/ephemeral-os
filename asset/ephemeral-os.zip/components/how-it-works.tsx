const steps = [
  {
    step: '01',
    title: 'Define a base image',
    description:
      'Package your tools, dependencies, and repo once. This snapshot becomes the shared base for every sandbox.',
  },
  {
    step: '02',
    title: 'Fork sandboxes on demand',
    description:
      'Spin up one — or thousands — of copy-on-write clones instantly. Each agent gets a clean, isolated environment.',
  },
  {
    step: '03',
    title: 'Run, audit, and dispose',
    description:
      'Agents work with shell, write, and edit tools. Every action is logged, then the sandbox vanishes when the job is done.',
  },
]

const stats = [
  { value: 'O(1)', label: 'Space per clone' },
  { value: '0.4s', label: 'To 128 sandboxes' },
  { value: '100%', label: 'Operations audited' },
  { value: '4', label: 'Platforms supported' },
]

export function HowItWorks() {
  return (
    <section id="how" className="border-y border-border bg-card/40">
      <div className="mx-auto max-w-6xl px-4 py-20 md:px-6 md:py-24">
        <div className="mx-auto mb-14 max-w-2xl text-center">
          <p className="mb-3 text-sm font-medium uppercase tracking-widest text-primary">
            How it works
          </p>
          <h2 className="text-balance text-3xl font-semibold tracking-tight md:text-4xl">
            From base image to disposable runtime
          </h2>
        </div>

        <ol className="grid gap-6 md:grid-cols-3">
          {steps.map((item) => (
            <li
              key={item.step}
              className="relative rounded-2xl border border-border bg-background p-6"
            >
              <span className="font-mono text-sm font-semibold text-primary">{item.step}</span>
              <h3 className="mt-3 text-lg font-semibold tracking-tight">{item.title}</h3>
              <p className="mt-2 text-pretty leading-relaxed text-muted-foreground">
                {item.description}
              </p>
            </li>
          ))}
        </ol>

        <dl className="mt-16 grid grid-cols-2 gap-6 border-t border-border pt-10 md:grid-cols-4">
          {stats.map((stat) => (
            <div key={stat.label} className="text-center">
              <dt className="sr-only">{stat.label}</dt>
              <dd className="font-mono text-3xl font-semibold tracking-tight text-foreground md:text-4xl">
                {stat.value}
              </dd>
              <p className="mt-1 text-sm text-muted-foreground">{stat.label}</p>
            </div>
          ))}
        </dl>
      </div>
    </section>
  )
}
