import Image from 'next/image'
import { ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function CtaFooter() {
  return (
    <>
      <section id="cta" className="mx-auto max-w-6xl px-4 py-20 md:px-6 md:py-24">
        <div className="flex flex-col items-center gap-6 rounded-3xl border border-border bg-card px-6 py-14 text-center md:px-12">
          <Image
            src="/ephemeral-os-logo.png"
            alt=""
            width={80}
            height={80}
            className="h-20 w-20 object-contain"
          />
          <h2 className="text-balance text-3xl font-semibold tracking-tight md:text-4xl">
            Ship agents that run anywhere
          </h2>
          <p className="max-w-xl text-pretty text-lg leading-relaxed text-muted-foreground">
            Start with a free sandbox and scale to thousands of concurrent agents when you&apos;re
            ready. No infrastructure to manage.
          </p>
          <div className="flex flex-col gap-3 sm:flex-row">
            <Button size="lg" nativeButton={false} render={<a href="#docs" />}>
              Get started
              <ArrowRight className="size-4" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              nativeButton={false}
              render={<a href="#docs" />}
            >
              Read the docs
            </Button>
          </div>
        </div>
      </section>

      <footer id="docs" className="border-t border-border">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-4 py-8 md:flex-row md:px-6">
          <div className="flex items-center gap-2.5">
            <Image
              src="/ephemeral-os-logo.png"
              alt="Ephemeral-OS logo"
              width={28}
              height={28}
              className="h-7 w-7 object-contain"
            />
            <span className="text-sm font-semibold tracking-tight">
              Ephemeral<span className="text-primary">-OS</span>
            </span>
          </div>
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} Ephemeral-OS. All rights reserved.
          </p>
          <nav aria-label="Footer" className="flex items-center gap-6">
            <a href="#features" className="text-sm text-muted-foreground hover:text-foreground">
              Features
            </a>
            <a href="#how" className="text-sm text-muted-foreground hover:text-foreground">
              How it works
            </a>
            <a href="#cta" className="text-sm text-muted-foreground hover:text-foreground">
              Get started
            </a>
          </nav>
        </div>
      </footer>
    </>
  )
}
